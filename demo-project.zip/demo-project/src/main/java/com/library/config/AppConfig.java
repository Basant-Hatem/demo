package com.library.config;

// BUG 26: missing import for ObjectMapper
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

// BUG 27: @Bean in a @Service class (not @Configuration) — won't register correctly
// BUG 28: @Service AND @Configuration conflict
import org.springframework.context.annotation.Configuration;

@Service
@Configuration
public class AppConfig {

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    // BUG 29: @Value on static field — Spring won't inject it
    @org.springframework.beans.factory.annotation.Value("${app.name}")
    private static String appName;
}
