package com.library.service;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

// BUG 30: manual logger field while @Slf4j is present
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// BUG 31: unused imports
import java.util.Date;
import java.util.LinkedHashMap;

@Slf4j
@Service
public class NotificationService {

    // BUG 30: @Slf4j + manual logger = duplicate
    private static final Logger logger = LoggerFactory.getLogger(NotificationService.class);

    public void notify(String message) {
        log.info("Notification: {}", message);
    }

    // BUG 32: @Scheduled in a @Service — OK here, but with parameters = BLOCKER
    @Scheduled(fixedRate = 5000)
    public void scheduledCleanup(String unexpectedParam) {
        log.info("Cleanup running...");
    }
}
