package com.library.service;

// BUG 19: missing import for List (used below but not imported)
import java.util.ArrayList;
import java.util.Optional;

// BUG 20: unused import
import java.util.TreeMap;
import java.util.Collections;

import com.library.model.Book;
import com.library.repository.BookRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Component;

@Slf4j
// BUG 21: @Service AND @Component together (redundant stereotype)
@Service
@Component
public class BookService {

    // BUG 22: @Autowired field injection (should use constructor injection)
    @Autowired
    private BookRepository bookRepository;

    // BUG 23: @Autowired field injection again
    @Autowired
    private NotificationService notificationService;

    public List<Book> getAllBooks() {
        log.info("Fetching all books");
        return bookRepository.findAll();
    }

    public Optional<Book> getById(Long id) {
        return bookRepository.findById(id);
    }

    public Book save(Book book) {
        notificationService.notify("Book saved: " + book.getTitle());
        return bookRepository.save(book);
    }

    public void delete(Long id) {
        bookRepository.deleteById(id);
    }
}
