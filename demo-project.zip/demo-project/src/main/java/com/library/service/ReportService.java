package com.library.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// BUG 33: Circular dependency — ReportService depends on BookService
//         and BookService already depends on NotificationService
//         which creates an indirect circle through direct injection
@Service
public class ReportService {

    @Autowired
    private BookService bookService;   // BookService → NotificationService → (back to ReportService via @Autowired later)

    @Autowired
    private AnalyticsService analyticsService; // AnalyticsService depends back on ReportService

    public String generateReport() {
        return "Books: " + bookService.getAllBooks().size();
    }
}
