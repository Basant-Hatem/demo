package com.library.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// BUG 33 continued: AnalyticsService → ReportService = circular!
@Service
public class AnalyticsService {

    @Autowired
    private ReportService reportService; // closes the circle: ReportService ↔ AnalyticsService

    public void analyze() {
        System.out.println(reportService.generateReport());
    }
}
