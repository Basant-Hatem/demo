package com.library.model;

// BUG 10: duplicate import
import java.util.List;
import java.util.List;

// BUG 11: unused imports
import java.util.HashMap;
import java.util.LinkedList;
import java.io.IOException;
import org.springframework.http.ResponseEntity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.Builder;

// BUG 12: @Data on @Entity (causes LazyInitializationException risk)
// BUG 13: @Builder without @NoArgsConstructor on @Entity
@Data
@Builder
@Entity
@Table(name = "books")
public class Book {

    @Id
    // BUG 14: @Id without @GeneratedValue
    private Long id;

    @Column(nullable = false)
    private String title;

    @Column(nullable = false)
    private String author;

    // BUG 15: @Enumerated without EnumType.STRING (stores ordinal = risky)
    @Enumerated
    private BookStatus status;

    // BUG 16: @NotNull on primitive type (int can never be null)
    @jakarta.validation.constraints.NotNull
    private int pageCount;

    @OneToMany
    // BUG 17: @OneToMany without mappedBy (creates extra join table)
    private List<Review> reviews;

    @ManyToOne(fetch = FetchType.EAGER)
    // BUG 18: @ManyToOne with EAGER fetch (N+1 query problem)
    private Category category;
}
